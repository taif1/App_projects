package com.gautam.medicinetime.report;



public enum  FilterType {

    ALL_MEDICINES,

    TAKEN_MEDICINES,

    IGNORED_MEDICINES
}
